/**
 * next.config.js
 *
 * We are loading only local images from `public/images/`, so no extra
 * `images.domains` configuration is needed.
 */
module.exports = {
  reactStrictMode: true
};
