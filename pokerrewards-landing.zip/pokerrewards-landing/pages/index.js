// pages/index.js

import Head from "next/head";
import Image from "next/image";

const sites = [
  {
    name: "BetOnline",
    href: "https://affiliate.example.com/betonline?ref=YOUR_TRACKING_CODE",
    img: "/images/betonline.png",
  },
  {
    name: "Americas Cardroom",
    href: "https://affiliate.example.com/americascardroom?ref=YOUR_TRACKING_CODE",
    img: "/images/americascardroom.png",
  },
  {
    name: "CoinPoker",
    href: "https://affiliate.example.com/coinpoker?ref=YOUR_TRACKING_CODE",
    img: "/images/coinpoker.png",
  },
  {
    name: "Everygame",
    href: "https://affiliate.example.com/everygame?ref=YOUR_TRACKING_CODE",
    img: "/images/everygame.png",
  },
  {
    name: "Ignition Casino",
    href: "https://affiliate.example.com/ignition?ref=YOUR_TRACKING_CODE",
    img: "/images/ignition.png",
  },
  {
    name: "PokerBros",
    href: "https://affiliate.example.com/pokerbros?ref=YOUR_TRACKING_CODE",
    img: "/images/pokerbros.png",
  },
  {
    name: "Stake.us",
    href: "https://affiliate.example.com/stakeus?ref=YOUR_TRACKING_CODE",
    img: "/images/stakeus.png",
  },
  {
    name: "Bovada",
    href: "https://affiliate.example.com/bovada?ref=YOUR_TRACKING_CODE",
    img: "/images/bovada.png",
  },
  {
    name: "ClubGG",
    href: "https://affiliate.example.com/clubgg?ref=YOUR_TRACKING_CODE",
    img: "/images/clubgg.png",
  },
  {
    name: "Phenom Poker",
    href: "https://affiliate.example.com/phenompoker?ref=YOUR_TRACKING_CODE",
    img: "/images/phenompoker.png",
  },
  {
    name: "PokerKing",
    href: "https://affiliate.example.com/pokerking?ref=YOUR_TRACKING_CODE",
    img: "/images/pokerking.png",
  },
  {
    name: "Redstar Poker",
    href: "https://affiliate.example.com/redstar?ref=YOUR_TRACKING_CODE",
    img: "/images/redstar.png",
  },
];

export default function Home() {
  return (
    <>
      <Head>
        <title>Poker Rewards Landing</title>
        <meta name="description" content="Welcome to Poker Rewards" />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
      </Head>

      <main style={{ padding: "2rem", fontFamily: "sans-serif" }}>
        <h1>Welcome to Poker Rewards</h1>
        <p>Click any logo below to visit our partner’s site:</p>

        <div
          style={{
            display: "flex",
            gap: "2rem",
            alignItems: "center",
            marginTop: "2rem",
            flexWrap: "wrap",
          }}
        >
          {sites.map((site) => (
            <div key={site.name} style={{ textAlign: "center" }}>
              <a
                href={site.href}
                target="_blank"
                rel="noopener noreferrer"
                style={{ display: "inline-block" }}
              >
                <Image
                  src={site.img}
                  alt={`${site.name} Logo`}
                  width={200}
                  height={100}
                  priority
                />
              </a>
              <p style={{ marginTop: "0.5rem" }}>{site.name}</p>
            </div>
          ))}
        </div>
      </main>
    </>
  );
}
